def get_user_list(data_file, target_file=None):
    user_list = []

    for line in open(data_file):
        login = line.split(':')[0]
        login = login.title()
        user_list.append(login)

    enum_user_list = enumerate(sorted(user_list), 1)

    if target_file:
        with open(target_file, 'w') as fw:
            for ln_no, u_name in enum_user_list:
                content = "{:>6}  {}".format(ln_no, u_name)
                print content
                fw.write(content + "\n")

    else:
        for ln_no, u_name in enum_user_list:
            print "{:>6}  {}".format(ln_no, u_name)


get_user_list('/etc/passwd', 'passwd.dat')