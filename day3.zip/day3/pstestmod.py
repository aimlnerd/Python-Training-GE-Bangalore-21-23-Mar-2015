from day3.pspack import psutils

print psutils

print psutils.power(4, 4)

print psutils.author