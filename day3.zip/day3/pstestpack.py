
#from sys import path
#path.append('lib')
import pspack

#print pspack.psutils.swap_me(12, 'perl')

print pspack.swap_me(12, 3)

