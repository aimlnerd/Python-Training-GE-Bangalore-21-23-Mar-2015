from sys import exc_info
from traceback import print_tb


class CustomFile(file):
    def __lshift__(self, other):
        self.seek(0, 0)
        content = self.readlines()[:other]
        return ''.join(content)

    def __rshift__(self, other):
        self.seek(0, 0)
        content = self.readlines()[-other:]
        return ''.join(content)

if __name__ == '__main__':
    try:
        with CustomFile('/etc/passwd12') as fp:
            print fp << 3

            print fp >> 3

    except IOError, e:
        print_tb(exc_info()[-1])
    except ZeroDivisionError, e:
        print e
        