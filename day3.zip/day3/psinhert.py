class Person(object):
    def __init__(self, name, gender):
        self.name = name
        self.gender = gender

    def dummy(self):
        print "dummy invoked"

    def get_info(self):
        print "name : ", self.name
        print "gender : ", self.gender


class Employee(Person):
    def __init__(self, eid, name, gender, desg):
        self.eid = eid
        self.desg = desg
        super(Employee, self).__init__(name, gender)

    def get_info(self):
        print "id : ", self.eid
        super(Employee, self).get_info()
        print "desg :", self.desg

if __name__ == '__main__':
    p = Employee('v4001', 'pam', 'male', 'clerk')
    p.get_info()