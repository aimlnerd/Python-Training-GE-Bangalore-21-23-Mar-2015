class RangeError(Exception):
    pass


def check4limit(value):
    if not 0.3 <= value <= 0.7:
        raise RangeError("value is far too high: {}".format(value))

    return True

try:
    check4limit(.9)
except RangeError, e:
    print e
    print type(e)