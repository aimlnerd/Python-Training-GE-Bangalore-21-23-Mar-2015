
class Demo(object):
    lang = "perl"

    def __init__(self, pm):
        self.__package_manager = pm

    def __get_package_manager(self):
        return self.__package_manager

    def wrapper(self):
        return self.__get_package_manager()


d = Demo('cpan')
print d._Demo__get_package_manager()
print Demo.lang
#print d.__get_package_manager()
#print d.wrapper()
#print d.package_manager
#print d.lang
