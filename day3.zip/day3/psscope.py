"""
a sample script to demo scope
"""

print __file__
print __name__
print __doc__