class Prime(object):
    def pprint(self):
        print "pprint() from the class Prime"

class Alpha(Prime):
    def pprint(self):
        print "pprint() from the class Alpha"


class Beta(object):
    def pprint(self):
        print "pprint() from the class Beta"


class Charlie(Beta, Alpha):
    def pprint(self):
        super(Alpha, self).pprint()


if __name__ == '__main__':
    c = Charlie()
    c.pprint()