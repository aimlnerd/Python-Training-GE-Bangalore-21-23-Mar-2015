
class Demo(object):
    pass


print Demo
print type(Demo)
print

dObj = Demo()
print dObj
print type(dObj)
