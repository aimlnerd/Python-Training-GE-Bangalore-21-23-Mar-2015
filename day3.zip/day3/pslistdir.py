from os import listdir, stat
from os.path import isfile, join
from time import ctime
from pprint import pprint as pp
from json import dump


def to_json(content, json_file):
    with open(json_file, 'w') as fw:
        dump(content, fw, indent=4)


def get_directory_listing(*args):
    if len(args) < 2:
        raise Exception("insuff. arguments to the function")

    json_file = args[-1]
    directories = args[:-1]
    content = {}

    for directory_name in directories:
        callable_obj = lambda filename: isfile(join(directory_name,
                                                    filename))

        file_names = filter(callable_obj, listdir(directory_name))
        temp = {}

        for file_name in file_names:
            abs_path = join(directory_name, file_name)
            file_stat = stat(abs_path)
            temp[file_name] = [file_stat.st_size, ctime(file_stat.st_mtime)]

        content[directory_name] = temp

    to_json(content, json_file)
    return json_file


file_content = get_directory_listing('/tmp', '.', 'tmp.json')
pp(file_content)