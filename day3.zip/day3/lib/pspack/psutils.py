"""
a sample py module
"""

author = 'jaya'
version = '0.0.1 beta'


def power(x, n):
    """
    power(), raises x to the power of n
    :param x: int
    :param n: int
    :return: int
    """
    return x ** n


def swap_me(a, b):
    """
    swap_me(), swaps the arguemnts
    :param a:
    :param b:
    :return:
    """
    return b, a


def main():
    print author
    print swap_me(10, 11)
    print power(4, 3)


if __name__ == '__main__':
    main()
