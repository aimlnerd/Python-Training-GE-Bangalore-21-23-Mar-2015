
n = 1010


def demo():
    global n
    n = 'pypi'
    print n

print n
demo()
del n
print n

