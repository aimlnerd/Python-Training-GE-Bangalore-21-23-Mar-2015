import re
import fileinput

for line in fileinput.input(inplace=True, backup='.bak'):
    print re.sub(':', ',', line),

