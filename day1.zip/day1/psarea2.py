from math import pi

radius = float(raw_input('enter the radius :'))

area = pi * (radius ** 2)
'''
{INDEX:FMT_str}
'''

content = "radius : {}\narea : {:.3f}".format(radius, area)

print content