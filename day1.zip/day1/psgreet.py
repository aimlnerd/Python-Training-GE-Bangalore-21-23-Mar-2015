#!/usr/bin/env python
#IO
name = raw_input('Enter the name :')
city = raw_input('Enter the city :')
zip_code = int(raw_input('Enter the zip code :'))

print "name :", name
print "city :", city
print zip_code
print type(zip_code)
