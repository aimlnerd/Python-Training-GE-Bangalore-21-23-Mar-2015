#print 1,2,['peter', 1,2],4,5

print 'kim',
print 'joe',
print 'kim',
print; print



print 'aman',
print 'tim'
