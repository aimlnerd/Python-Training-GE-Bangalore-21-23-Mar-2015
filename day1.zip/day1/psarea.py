from math import pi

radius = float(raw_input('enter the radius :'))

area = pi * (radius ** 2)
'''
string formating

a % b
a + b, c
'''
content =  "radius : %f\narea : %.3f" % (radius, area)

print content.upper()