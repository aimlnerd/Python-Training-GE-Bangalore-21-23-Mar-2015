name, age, gender = 'sara', 4, 'female'

with open('mighty.csv', 'w') as fw:
    for i in range(3):
        content = "{:>22},{:>5},{:>12}".format(name, age, gender)
        fw.write(content+"\n")



