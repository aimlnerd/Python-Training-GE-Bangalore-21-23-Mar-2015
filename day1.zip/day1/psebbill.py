from random import choice
help(choice)

def compute_bill(units):
    amount = 0

    if units <= 100:
        amount = units
    elif units <= 200:
        amount = units * 1.5;
    elif units <= 500:
        amount = (200 * 2) + (units-200) * 3;
    elif units > 500:
        amount = (200 * 3) + (300 * 4) + (units - 500) * 5.75;

    return amount

billable = compute_bill(501)
print "amount : {:.2f}".format(billable)
