name, age, gender = 'sara', 4, 'female'

print "|{}|{}|{}|".format(name, age, gender)
print "|{:>20}|{:>5}|{:>12}|".format(name, age, gender)
print "|{:<20}|{:<5}|{:<12}|".format(name, age, gender)
print "|{:^20}|{:^5}|{:^12}|".format(name, age, gender)

print "{:20},{:5},{:12}".format(name, age, gender)
